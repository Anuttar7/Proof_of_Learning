import matplotlib.pyplot as plt
import numpy as np

# A = [[[1 for k in range(10)] for j in range(5)] for i in range(4)]

# print(np.sum(A, axis=1).shape)
# print(np.sum(A, axis=1))
# print(np.mean(A, axis=1).shape)
# print(np.mean(A, axis=1))

# x = np.linspace(0, 10, 100)
# y = np.sin(x)
# plt.plot(x, y, label=r'$cos(W_{t}, W^{\prime}_{t})$')
# plt.ylabel(r'$max(|| \epsilon _{repr} ||)$')
# plt.legend()
# plt.show()